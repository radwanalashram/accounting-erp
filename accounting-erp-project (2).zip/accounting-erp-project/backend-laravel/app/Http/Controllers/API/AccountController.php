<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;

class AccountController extends Controller
{
    public function index()
    {
        return response()->json([
            'message' => 'Accounts API Working'
        ]);
    }
}
