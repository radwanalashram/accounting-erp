export default function App() {
  return (
    <div dir="rtl" style={{padding:'40px', fontFamily:'sans-serif'}}>
      <h1>نظام ERP المحاسبي</h1>
      <p>تم إنشاء المشروع بنجاح</p>
    </div>
  );
}
