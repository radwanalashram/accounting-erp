# Accounting ERP Project

## يحتوي المشروع على:
- Frontend React Starter
- Backend Laravel API Starter

## التشغيل
### Frontend
npm install
npm run dev

### Backend
composer install
php artisan serve
